<?php $__env->startSection('title', 'Community reports'); ?>
<?php $__env->startSection('content'); ?>
<h1>Problems in your area</h1>
<p class="lead">Open reports from other citizens. Tell us if a problem affects you too, if you saw it is still there, or if it has already been fixed. Your votes raise or lower its priority.</p>

<form method="GET" action="<?php echo e(route('community.index')); ?>" class="filter filter-row">
  <label>Ward / area
    <input name="ward" value="<?php echo e($ward); ?>" maxlength="60" placeholder="e.g. Ward 17 or Mirpur">
  </label>
  <label>Category
    <select name="category">
      <option value="">All categories</option>
      <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $c): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <option value="<?php echo e($c->id); ?>" <?php if($filter === (int) $c->id): echo 'selected'; endif; ?>><?php echo e($c->name); ?></option>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </select>
  </label>
  <button class="btn small" type="submit">Show</button>
</form>

<?php if($reports->isEmpty()): ?>
  <div class="empty"><p>No open reports from other citizens match this filter.</p></div>
<?php else: ?>
  <ul class="report-list">
    <?php $__currentLoopData = $reports; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $r): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
      <li>
        <a href="<?php echo e(route('community.show', $r)); ?>">
          <span class="plate small"><?php echo e($r->category->name); ?></span>
          <strong><?php echo e($r->title); ?></strong>
          <span class="meta"><?php echo e($r->address); ?><?php echo e($r->ward ? ' · '.$r->ward : ''); ?> · <?php echo e($r->affected_count); ?> affected · <?php echo e($r->still_there_count); ?> saw it</span>
          <span class="status"><?php echo $__env->make('reports._priority', ['report' => $r], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?></span>
        </a>
      </li>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
  </ul>
<?php endif; ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH E:\cse471\nagarbondhu-laravel\resources\views/community/index.blade.php ENDPATH**/ ?>