<?php $__env->startSection('title', 'Track a report'); ?>
<?php $__env->startSection('content'); ?>
<h1>Track a report</h1>
<p class="lead">Enter the tracking code you got when the report was submitted (for example NB-261115-K7Q2M).</p>

<form method="GET" action="<?php echo e(route('track')); ?>" class="filter filter-row">
  <label>Tracking code <input name="code" value="<?php echo e($code); ?>" maxlength="20" required placeholder="NB-YYMMDD-XXXXX"></label>
  <button class="btn small" type="submit">Track</button>
</form>

<?php if($code !== '' && ! $report): ?>
  <div class="notice bad" role="alert">No report has the code <?php echo e($code); ?>. Check it and try again.</div>
<?php elseif($report): ?>
  <article class="report">
    <header>
      <span class="plate"><?php echo e($report->category->name); ?></span>
      <span class="status"><?php echo e($report->status); ?></span>
    </header>
    <h2><?php echo e($report->title); ?></h2>
    <dl class="facts">
      <dt>Tracking code</dt><dd><code><?php echo e($report->tracking_code); ?></code></dd>
      <dt>Location</dt><dd><?php echo e($report->address); ?><?php echo e($report->ward ? ' · '.$report->ward : ''); ?></dd>
      <dt>Priority</dt><dd><?php echo e($report->priority_level); ?></dd>
    </dl>
    <?php echo $__env->make('reports._timeline', ['histories' => $report->histories], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
  </article>
<?php endif; ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH E:\cse471\nagarbondhu-laravel\resources\views/track/index.blade.php ENDPATH**/ ?>