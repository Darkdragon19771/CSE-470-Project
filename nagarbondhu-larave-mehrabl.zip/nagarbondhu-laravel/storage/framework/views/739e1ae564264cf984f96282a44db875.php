
<h2>Status history</h2>
<ol class="timeline">
  <?php $__currentLoopData = $histories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $h): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <li>
      <span class="when"><?php echo e($h->created_at->format('d M Y, H:i')); ?></span>
      <strong>
        <?php if($h->from_status && $h->from_status !== $h->to_status): ?>
          <?php echo e($h->from_status); ?> &rarr; <?php echo e($h->to_status); ?>

        <?php elseif($h->from_status): ?>
          <?php echo e($h->to_status); ?> <span class="muted">(priority)</span>
        <?php else: ?>
          <?php echo e($h->to_status); ?>

        <?php endif; ?>
      </strong>
      <?php if($h->note): ?><span class="note"><?php echo e($h->note); ?></span><?php endif; ?>
      <?php if(! empty($showActors) && $h->user): ?><span class="muted">by <?php echo e($h->user->name); ?></span><?php endif; ?>
    </li>
  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</ol>
<?php /**PATH E:\cse471\nagarbondhu-laravel\resources\views/reports/_timeline.blade.php ENDPATH**/ ?>