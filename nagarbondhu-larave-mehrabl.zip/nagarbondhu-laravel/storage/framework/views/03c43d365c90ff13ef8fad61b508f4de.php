<?php $__env->startSection('title', $report->title); ?>
<?php $__env->startSection('content'); ?>
<p><a href="<?php echo e(route('community.index')); ?>">&larr; Community reports</a></p>
<article class="report">
  <header>
    <span class="plate"><?php echo e($report->category->name); ?></span>
    <span><?php echo $__env->make('reports._priority', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?> <span class="status"><?php echo e($report->status); ?></span></span>
  </header>
  <h1><?php echo e($report->title); ?></h1>
  <dl class="facts">
    <dt>Location</dt><dd><?php echo e($report->address); ?><?php echo e($report->ward ? ' · '.$report->ward : ''); ?></dd>
    <dt>Reported</dt><dd><?php echo e($report->created_at->format('d M Y')); ?></dd>
    <dt>Tracking code</dt><dd><code><?php echo e($report->tracking_code); ?></code></dd>
  </dl>
  <p class="body-text"><?php echo nl2br(e($report->description)); ?></p>
  <?php if($report->evidence_path): ?>
    <figure><img src="<?php echo e($report->evidenceUrl()); ?>" alt="Evidence photo for this report"></figure>
  <?php endif; ?>

  <h2>Do you know this problem?</h2>
  <?php if($report->isClosed()): ?>
    <p class="muted">This report is <?php echo e(strtolower($report->status)); ?>, so it no longer takes votes.</p>
  <?php endif; ?>
  <div class="votes">
    <?php $__currentLoopData = \App\Models\ReportVote::LABELS; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $type => $label): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
      <?php ($mine = in_array($type, $myVotes, true)); ?>
      <div class="vote <?php echo e($mine ? 'on' : ''); ?>">
        <span class="vote-count"><?php echo e($report->voteCount($type)); ?></span>
        <span class="vote-label"><?php echo e($label); ?></span>
        <?php if (! ($report->isClosed())): ?>
          <?php if($mine): ?>
            <form method="POST" action="<?php echo e(route('reports.votes.destroy', [$report, $type])); ?>" class="inline">
              <?php echo csrf_field(); ?> <?php echo method_field('DELETE'); ?>
              <button class="btn small ghost" type="submit">Take back</button>
            </form>
          <?php else: ?>
            <form method="POST" action="<?php echo e(route('reports.votes.store', $report)); ?>" class="inline">
              <?php echo csrf_field(); ?> <input type="hidden" name="type" value="<?php echo e($type); ?>">
              <button class="btn small" type="submit">Vote</button>
            </form>
          <?php endif; ?>
        <?php endif; ?>
      </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
  </div>
  <p class="muted">“Still there” and “Already fixed” replace each other.</p>
</article>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH E:\cse471\nagarbondhu-laravel\resources\views/community/show.blade.php ENDPATH**/ ?>