<?php $__env->startSection('title', 'Report city problems'); ?>
<?php $__env->startSection('content'); ?>
<section class="hero">
  <h1>See a problem on your street? Put it on record.</h1>
  <p class="lead">NagarBondhu lets you report waterlogging, broken roads and other city problems so the right authority can see them and act.</p>
  <p><a class="btn" href="<?php echo e(route('register')); ?>">Create a free account</a>
     <a class="btn ghost" href="<?php echo e(route('login')); ?>">I already have an account</a></p>
</section>
<section>
  <h2>What you can report</h2>
  <ul class="plates">
    <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $c): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
      <li class="plate" title="<?php echo e($c->description); ?>"><?php echo e($c->name); ?></li>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
  </ul>
</section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH E:\cse471\nagarbondhu-laravel\resources\views/home/index.blade.php ENDPATH**/ ?>