<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title><?php echo $__env->yieldContent('title', 'NagarBondhu'); ?> – NagarBondhu</title>
  <link rel="preconnect" href="https://fonts.googleapis.com">
  <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
  <link href="https://fonts.googleapis.com/css2?family=Bricolage+Grotesque:wght@600;800&family=Hind+Siliguri:wght@400;500;600&display=swap" rel="stylesheet">
  <link rel="stylesheet" href="<?php echo e(asset('css/style.css')); ?>">
</head>
<body>
<header class="site-header">
  <div class="wrap bar">
    <a class="brand" href="<?php echo e(route('home')); ?>">Nagar<span>Bondhu</span></a>
    <nav>
      <?php if(auth()->guard()->check()): ?>
        <a href="<?php echo e(route('reports.index')); ?>">My reports</a>
        <a href="<?php echo e(route('community.index')); ?>">Community</a>
        <a href="<?php echo e(route('track')); ?>">Track</a>
        <?php if(auth()->user()->isAdmin()): ?><a href="<?php echo e(route('admin.reports.index')); ?>">Admin</a><?php endif; ?>
        <a href="<?php echo e(route('reports.create')); ?>" class="nav-cta">Report a problem</a>
        <form method="POST" action="<?php echo e(route('logout')); ?>" class="inline">
          <?php echo csrf_field(); ?>
          <button class="link-btn" type="submit">Log out (<?php echo e(auth()->user()->name); ?>)</button>
        </form>
      <?php else: ?>
        <a href="<?php echo e(route('track')); ?>">Track a report</a>
        <a href="<?php echo e(route('login')); ?>">Log in</a>
        <a href="<?php echo e(route('register')); ?>" class="nav-cta">Create account</a>
      <?php endif; ?>
    </nav>
  </div>
</header>
<main class="wrap">
  <?php if(session('success')): ?><div class="notice ok" role="status"><?php echo e(session('success')); ?></div><?php endif; ?>
  <?php if(session('error')): ?><div class="notice bad" role="alert"><?php echo e(session('error')); ?></div><?php endif; ?>
  <?php echo $__env->yieldContent('content'); ?>
</main>
<footer class="wrap site-footer">NagarBondhu – a civic problem reporting platform for Bangladesh · CSE 470 project</footer>
<script src="<?php echo e(asset('js/app.js')); ?>"></script>
</body>
</html>
<?php /**PATH E:\cse471\nagarbondhu-laravel\resources\views/layouts/app.blade.php ENDPATH**/ ?>