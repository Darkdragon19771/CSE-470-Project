<?php $__env->startSection('title', 'My reports'); ?>
<?php $__env->startSection('content'); ?>
<div class="page-head">
  <h1>My reports</h1>
  <a class="btn" href="<?php echo e(route('reports.create')); ?>">Report a problem</a>
</div>

<form method="GET" action="<?php echo e(route('reports.index')); ?>" class="filter">
  <label>Show
    <select name="category" onchange="this.form.submit()">
      <option value="">All categories</option>
      <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $c): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <option value="<?php echo e($c->id); ?>" <?php if($filter === (int) $c->id): echo 'selected'; endif; ?>><?php echo e($c->name); ?></option>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </select>
  </label>
  <noscript><button class="btn small" type="submit">Apply</button></noscript>
</form>

<?php if($reports->isEmpty()): ?>
  <div class="empty">
    <p><?php echo e($filter ? 'You have no reports in this category.' : 'You haven’t reported anything yet.'); ?></p>
    <a class="btn" href="<?php echo e(route('reports.create')); ?>">Report your first problem</a>
  </div>
<?php else: ?>
  <ul class="report-list">
    <?php $__currentLoopData = $reports; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $r): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
      <li>
        <a href="<?php echo e(route('reports.show', $r)); ?>">
          <span class="plate small"><?php echo e($r->category->name); ?></span>
          <strong><?php echo e($r->title); ?></strong>
          <span class="meta"><?php echo e($r->address); ?> · <?php echo e($r->created_at->format('d M Y')); ?></span>
          <span class="status"><?php echo e($r->status); ?></span>
          <span class="meta"><?php echo e($r->tracking_code); ?> · Priority <?php echo e($r->priority_level); ?></span>
        </a>
      </li>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
  </ul>
<?php endif; ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH E:\cse471\nagarbondhu-laravel\resources\views/reports/index.blade.php ENDPATH**/ ?>