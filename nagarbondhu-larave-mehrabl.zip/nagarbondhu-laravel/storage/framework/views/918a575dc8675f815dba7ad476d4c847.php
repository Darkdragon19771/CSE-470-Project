
<span class="priority p-<?php echo e(strtolower($report->priority_level)); ?>" title="Priority score <?php echo e($report->priority_score); ?> / 100">
  <?php echo e($report->priority_level); ?> · <?php echo e($report->priority_score); ?>

</span>
<?php /**PATH E:\cse471\nagarbondhu-laravel\resources\views/reports/_priority.blade.php ENDPATH**/ ?>