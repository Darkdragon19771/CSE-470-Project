<?php $__env->startSection('title', $report->title); ?>
<?php $__env->startSection('content'); ?>
<p><a href="<?php echo e(route('reports.index')); ?>">&larr; My reports</a></p>
<article class="report">
  <header>
    <span class="plate"><?php echo e($report->category->name); ?></span>
    <span><?php echo $__env->make('reports._priority', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?> <span class="status"><?php echo e($report->status); ?></span></span>
  </header>
  <h1><?php echo e($report->title); ?></h1>
  <dl class="facts">
    <dt>Tracking code</dt><dd><a href="<?php echo e(route('track', ['code' => $report->tracking_code])); ?>"><code><?php echo e($report->tracking_code); ?></code></a> <span class="muted">– share it so anyone can follow progress</span></dd>
    <dt>Community</dt><dd><?php echo e($report->voteCount('affected')); ?> affected · <?php echo e($report->voteCount('still_there')); ?> saw it still there · <?php echo e($report->voteCount('fixed')); ?> say it is fixed</dd>
    <dt>Location</dt><dd><?php echo e($report->address); ?><?php echo e($report->ward ? ' · '.$report->ward : ''); ?></dd>
    <dt>Reported</dt><dd><?php echo e($report->created_at->format('d M Y, H:i')); ?></dd>
    <?php if($report->updated_at->gt($report->created_at)): ?>
      <dt>Last edited</dt><dd><?php echo e($report->updated_at->format('d M Y, H:i')); ?></dd>
    <?php endif; ?>
  </dl>
  <p class="body-text"><?php echo nl2br(e($report->description)); ?></p>
  <?php if($report->evidence_path): ?>
    <figure><img src="<?php echo e($report->evidenceUrl()); ?>" alt="Evidence photo for this report"></figure>
  <?php endif; ?>

  <?php echo $__env->make('reports._timeline', ['histories' => $report->histories], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

  <?php if($report->isEditable()): ?>
    <div class="actions">
      <a class="btn" href="<?php echo e(route('reports.edit', $report)); ?>">Edit report</a>
      <form method="POST" action="<?php echo e(route('reports.destroy', $report)); ?>" class="inline"
            data-confirm="Delete this report? This cannot be undone.">
        <?php echo csrf_field(); ?> <?php echo method_field('DELETE'); ?>
        <button class="btn danger" type="submit">Delete report</button>
      </form>
    </div>
  <?php else: ?>
    <p class="muted">This report is being handled, so it can no longer be edited or deleted.</p>
  <?php endif; ?>
</article>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH E:\cse471\nagarbondhu-laravel\resources\views/reports/show.blade.php ENDPATH**/ ?>