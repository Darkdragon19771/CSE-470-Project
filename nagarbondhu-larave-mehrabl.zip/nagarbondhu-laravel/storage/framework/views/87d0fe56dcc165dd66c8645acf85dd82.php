<?php ($selected = (int) old('category_id', $report->category_id ?? 0)); ?>
<form method="POST" action="<?php echo e($action); ?>" enctype="multipart/form-data" class="report-form" novalidate>
  <?php echo csrf_field(); ?>
  <?php if(isset($report)): ?> <?php echo method_field('PUT'); ?> <?php endif; ?>

  <fieldset>
    <legend>What kind of problem is it?</legend>
    <div class="cat-grid">
      <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $c): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <label class="cat-option">
          <input type="radio" name="category_id" value="<?php echo e($c->id); ?>" <?php if($selected === (int) $c->id): echo 'checked'; endif; ?> required>
          <span><strong><?php echo e($c->name); ?></strong><small><?php echo e($c->description); ?></small></span>
        </label>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
    <?php $__errorArgs = ['category_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><p class="field-error"><?php echo e($message); ?></p><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
  </fieldset>

  <label>Short title
    <input name="title" value="<?php echo e(old('title', $report->title ?? '')); ?>" maxlength="120" required placeholder="e.g. Deep pothole in front of Rahman Market">
  </label>
  <?php $__errorArgs = ['title'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><p class="field-error"><?php echo e($message); ?></p><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

  <label>Describe the problem
    <textarea name="description" rows="5" maxlength="2000" required data-counter="desc-count"
      placeholder="What is wrong, how long has it been like this, who does it affect?"><?php echo e(old('description', $report->description ?? '')); ?></textarea>
    <span class="counter"><span id="desc-count">0</span> / 2000</span>
  </label>
  <?php $__errorArgs = ['description'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><p class="field-error"><?php echo e($message); ?></p><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

  <div class="two-col">
    <label>Where is it? <input name="address" value="<?php echo e(old('address', $report->address ?? '')); ?>" maxlength="200" required placeholder="Road, landmark, area"></label>
    <label>Ward / area <span class="muted">(optional)</span> <input name="ward" value="<?php echo e(old('ward', $report->ward ?? '')); ?>" maxlength="60" placeholder="e.g. Ward 17"></label>
  </div>
  <?php $__errorArgs = ['address'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><p class="field-error"><?php echo e($message); ?></p><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
  <?php $__errorArgs = ['ward'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><p class="field-error"><?php echo e($message); ?></p><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

  <label>Photo evidence <span class="muted">(optional · JPG, PNG or WebP · up to 5 MB)</span>
    <input type="file" name="evidence" id="evidence" accept="image/jpeg,image/png,image/webp">
  </label>
  <?php $__errorArgs = ['evidence'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><p class="field-error"><?php echo e($message); ?></p><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

  <?php if(isset($report) && $report->evidence_path): ?>
    <div class="current-evidence">
      <img src="<?php echo e($report->evidenceUrl()); ?>" alt="Current evidence photo">
      <label class="check"><input type="checkbox" name="remove_evidence" value="1"> Remove this photo (or choose a new one above to replace it)</label>
    </div>
  <?php endif; ?>
  <img id="evidence-preview" class="preview" alt="Preview of the selected photo" hidden>

  <div class="actions">
    <button class="btn" type="submit"><?php echo e($submitLabel); ?></button>
    <a class="btn ghost" href="<?php echo e($cancelUrl); ?>">Cancel</a>
  </div>
</form>
<?php /**PATH E:\cse471\nagarbondhu-laravel\resources\views/reports/_form.blade.php ENDPATH**/ ?>