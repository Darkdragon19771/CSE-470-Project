<?php $__env->startSection('title', 'Log in'); ?>
<?php $__env->startSection('content'); ?>
<section class="auth">
  <h1>Log in</h1>
  <form method="POST" action="<?php echo e(route('login')); ?>" novalidate>
    <?php echo csrf_field(); ?>
    <label>Email <input type="email" name="email" value="<?php echo e(old('email')); ?>" autocomplete="email" required autofocus></label>
    <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><p class="field-error"><?php echo e($message); ?></p><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
    <label>Password <input type="password" name="password" autocomplete="current-password" required></label>
    <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><p class="field-error"><?php echo e($message); ?></p><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
    <button class="btn" type="submit">Log in</button>
  </form>
  <p class="muted">New here? <a href="<?php echo e(route('register')); ?>">Create an account</a></p>
</section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH E:\cse471\nagarbondhu-laravel\resources\views/auth/login.blade.php ENDPATH**/ ?>