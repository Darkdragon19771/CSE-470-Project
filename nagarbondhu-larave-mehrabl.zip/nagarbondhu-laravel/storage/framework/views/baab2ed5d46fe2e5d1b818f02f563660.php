<?php $__env->startSection('title', 'Edit report'); ?>
<?php $__env->startSection('content'); ?>
<h1>Edit report</h1>
<p class="lead">You can change a report until staff start reviewing it.</p>
<?php echo $__env->make('reports._form', [
    'action' => route('reports.update', $report),
    'submitLabel' => 'Save changes',
    'cancelUrl' => route('reports.show', $report),
], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH E:\cse471\nagarbondhu-laravel\resources\views/reports/edit.blade.php ENDPATH**/ ?>