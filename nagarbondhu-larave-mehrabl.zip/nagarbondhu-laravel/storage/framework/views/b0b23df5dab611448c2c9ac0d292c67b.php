<?php $__env->startSection('title', 'Report a problem'); ?>
<?php $__env->startSection('content'); ?>
<h1>Report a problem</h1>
<p class="lead">Pick a category and describe what you see. Your report starts with the status “Submitted”.</p>
<?php echo $__env->make('reports._form', [
    'action' => route('reports.store'),
    'submitLabel' => 'Submit report',
    'cancelUrl' => route('reports.index'),
], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH E:\cse471\nagarbondhu-laravel\resources\views/reports/create.blade.php ENDPATH**/ ?>