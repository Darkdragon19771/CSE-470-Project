<?php

namespace Database\Seeders;

use App\Models\Category;
use Illuminate\Database\Seeder;

class CategorySeeder extends Seeder
{
    public function run(): void
    {
        $categories = [
            ['Waterlogging', 'Standing water on roads or in neighbourhoods after rain'],
            ['Blocked Drain', 'Clogged or overflowing drains and sewers'],
            ['Damaged Road', 'Cracked, broken or collapsed road surface'],
            ['Pothole', 'Holes in the carriageway that endanger vehicles and people'],
            ['Illegal Garbage Dumping', 'Waste dumped outside designated collection points'],
            ['Broken Streetlight', 'Streetlights that are dark, flickering or damaged'],
            ['Open Manhole', 'Missing or broken manhole covers'],
        ];

        foreach ($categories as [$name, $description]) {
            Category::updateOrCreate(['name' => $name], ['description' => $description]);
        }
    }
}
