<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;

class Report extends Model
{
    public const STATUS_SUBMITTED = 'Submitted';

    protected $fillable = [
        'category_id', 'title', 'description', 'address', 'ward', 'evidence_path',
    ];

    public function user(): BelongsTo
    {
        return $this->belongsTo(User::class);
    }

    public function category(): BelongsTo
    {
        return $this->belongsTo(Category::class);
    }

    /** A citizen may change or delete a report only until staff start handling it. */
    public function isEditable(): bool
    {
        return $this->status === self::STATUS_SUBMITTED;
    }

    public function evidenceUrl(): ?string
    {
        return $this->evidence_path ? asset('storage/'.$this->evidence_path) : null;
    }
}
