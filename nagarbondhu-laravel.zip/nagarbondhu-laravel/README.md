# NagarBondhu – Smart Urban Problem Reporting & Management System

CSE 470 project. **Implemented so far: F1 – Multi-Category Civic Issue Reporting**, plus register / login / logout (supporting functionality, not counted as a feature).

## Tech stack
| Layer | Technology |
|---|---|
| Backend | **Laravel 12** (PHP 8.2+), MVC |
| Database | SQLite by default; MySQL by editing `.env` |
| Frontend | Blade templates containing plain HTML, CSS and JavaScript (`public/css/style.css`, `public/js/app.js`) |

Approved by the section faculty (Discord, 14 Nov 2026: plain PHP not allowed, Laravel allowed; email: no Python frameworks, no MERN).

## Setup
Requirements: PHP 8.2+ (extensions: `pdo_sqlite`, `mbstring`, `fileinfo`, `openssl`, `tokenizer`, `xml`, `ctype`, `json`) and [Composer](https://getcomposer.org).

```bash
composer install
cp .env.example .env
php artisan key:generate
touch database/database.sqlite          # Windows (cmd): type nul > database\database.sqlite
php artisan migrate --seed              # creates tables + the 7 report categories
php artisan storage:link                # makes uploaded photos viewable
php artisan serve                       # http://localhost:8000
```

Run the tests: `php artisan test`

To use MySQL instead: create an empty database, then in `.env` set `DB_CONNECTION=mysql`, `DB_DATABASE`, `DB_USERNAME`, `DB_PASSWORD`, and run `php artisan migrate --seed`.

If photo uploads fail, raise `upload_max_filesize` and `post_max_size` in `php.ini` to at least 6M (PHP's default is 2M; the app allows 5 MB).

## MVC map (files added on top of the Laravel skeleton)
```
routes/web.php                                  URL -> controller
app/Models/        User, Category, Report       Eloquent models (data + relationships)
app/Http/Controllers/  HomeController, AuthController, ReportController
app/Http/Requests/ReportRequest.php             validation rules for F1
resources/views/   layouts/app, home/, auth/, reports/   Blade views (HTML)
database/migrations/  users (+phone, role), categories, reports
database/seeders/  CategorySeeder
tests/Feature/ReportTest.php                    feature tests for F1
```

## F1 behaviour
A logged-in citizen can create, list (with category filter), view, edit and delete **their own** reports. Each has a category, title, description, location text, optional ward and an optional photo (JPG/PNG/WebP, ≤ 5 MB). New reports start as `Submitted`; edit/delete is allowed only while the status is `Submitted`. Other citizens' reports return 404.
